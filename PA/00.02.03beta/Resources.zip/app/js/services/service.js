(function() {
  'use strict';
  var angular, app;

  angular = this.angular;

  app = angular.module('opsiModule.services', []);

}).call(this);
